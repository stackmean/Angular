angular.module('marketApp')
	.directive('compilationLinkDir',function(){
		
	})