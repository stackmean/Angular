angular.module('marketApp')
	.controller('CustomDirCtrl', ['$scope', function($scope){
		$scope.name;
	}])