'use strict';

/**
 * @ngdoc overview
 * @name marketApp
 * @description
 * # marketApp
 *
 * Main module of the application.
 */
angular
  .module('marketApp', [
    'ngAnimate',
    'ngAria',
    'ngCookies',
    'ngMessages',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
	'ui.router'
  ])
  
  .config(function($stateProvider, $urlRouterProvider){
	$urlRouterProvider.otherwise('/profile');
	$stateProvider	
		.state('main',{
			url: "/",
			views :{
				'viewA':{
					templateUrl: 'views/main.html',
					controller: 'MainCtrl'
				},
				'viewB':{
					templateUrl: 'views/profile.html',
					controller: 'ProfileCtrl'
				}
			}			
		})
		.state('main.usastates', {			
			 url: "/usastates",
			 templateUrl: 'views/usastates.html',
			 controller: 'UsaStateCtrl'
		})
		.state('customdirective', {			
			url: "/customdirective",
			templateUrl: 'views/customdirective.html',
			controller: 'CustomDirCtrl'
		})
  })
  
  
  // .config(function ($routeProvider) {
    // $routeProvider
      // .when('/', {
        // templateUrl: 'views/main.html',
        // controller: 'MainCtrl',
        // controllerAs: 'main'
      // })
      // .when('/about', {
        // templateUrl: 'views/about.html',
        // controller: 'AboutCtrl',
        // controllerAs: 'about'
      // })
      // .otherwise({
        // redirectTo: '/'
      // });
  // });
