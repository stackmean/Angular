angular.module('marketApp')
	.directive('customDir',function(){
		return {
			replace: false,
			restrict: 'E',
			template: '<h3>Your name is {{name}}</h3>',
		}
	});
	
	//http://timothymartin.azurewebsites.net/angularjs-directives/
	
	//http://www.infragistics.com/community/blogs/dhananjay_kumar/archive/2015/06/11/understanding-scopes-in-angularjs-custom-directives.aspx